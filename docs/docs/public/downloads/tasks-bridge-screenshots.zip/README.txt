Tasks Bridge 2.11.1 screenshots

Real Obsidian UI with fictional demonstration data.
Desktop: 1400 x 1000 PNG. Mobile: 860 x 1864 PNG, captured using Obsidian mobile emulation.

Suggested upload order:
1. tasks-list.png - Bases Tasks List and Project overview
2. task-document.png - Native task document and Markdown notes
3. task-blocks.png - Embedded task cards
4. query-block.png - Todoist query block in dark mode
5. mobile-task.png - Mobile task document
6. mobile-edit.png - Mobile task editor
